/*
Plugin Name: WEBar
Description: HANDLE CUSTOM BAR
Version: 2.0
Author: Evgen 
*/

 // Remove the admin bar from the front end
 add_filter('show_admin_bar', '__return_false');